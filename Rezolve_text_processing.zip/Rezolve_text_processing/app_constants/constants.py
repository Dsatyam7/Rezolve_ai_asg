import os
from dotenv import load_dotenv

load_dotenv(".env.base")

MAX_TEXT_LENGTH = os.environ["MAX_TEXT_LENGTH"]
AZURE_OPENAI_API_KEY = os.environ["OPENAI_API_KEY"]
AZURE_OPENAI_GPT_4O_MODEL_NAME = os.environ["AZURE_OPENAI_GPT_4O_MODEL_NAME"]
AZURE_OPENAI_API_VERSION = os.environ["AZURE_OPENAI_API_VERSION"]
AZURE_OPENAI_ENDPOINT = os.environ["AZURE_OPENAI_ENDPOINT"]
