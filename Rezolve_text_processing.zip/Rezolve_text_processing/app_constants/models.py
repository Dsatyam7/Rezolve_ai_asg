from pydantic import BaseModel
from typing import List


class TextRequest(BaseModel):
    text: str


class ProcessedTextResponse(BaseModel):
    summary: str
    sentiment: str
    keywords: List[str]


class HistoryResponse(BaseModel):
    history: List[ProcessedTextResponse]