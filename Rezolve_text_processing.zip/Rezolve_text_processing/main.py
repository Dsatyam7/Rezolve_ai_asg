from fastapi import FastAPI
from core.services.routes import router

def create_app():
    app = FastAPI(title="Text Processing API")
    app.include_router(router)
    return app


app = create_app()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)