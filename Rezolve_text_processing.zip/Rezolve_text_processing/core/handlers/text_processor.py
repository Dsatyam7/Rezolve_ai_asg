from openai import AzureOpenAI
from core.utils.utils import extract_keywords
from app_constants.constants import *
from app_constants.models import *

history_store = []

azure_openai_client = AzureOpenAI(
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        azure_endpoint=AZURE_OPENAI_ENDPOINT
    )
def process_text(text: str):

    summary_response = azure_openai_client.chat.completions.create(
        model=AZURE_OPENAI_GPT_4O_MODEL_NAME,
        messages=[{"role": "system", "content": "Summarize the following text."},
                  {"role": "user", "content": text}]
    )
    summary = summary_response.choices[0].message.content

    sentiment_response = azure_openai_client.chat.completions.create(
        model=AZURE_OPENAI_GPT_4O_MODEL_NAME,
        messages=[{"role": "system", "content": "Analyze the sentiment of the following text."},
                  {"role": "user", "content": text}]
    )
    sentiment = sentiment_response.choices[0].message.content

    keywords = extract_keywords(text)

    result = {
        "summary": summary,
        "sentiment": sentiment,
        "keywords": keywords,
    }
    # resulting_schema = ProcessedTextResponse(summary=summary, sentiment=sentiment, keywords=keywords)
    history_store.append(result)
    return result


def get_history():
    return {"history": history_store}
