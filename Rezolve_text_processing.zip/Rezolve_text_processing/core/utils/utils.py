from openai import AzureOpenAI
from app_constants.constants import *

azure_openai_client = AzureOpenAI(
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        azure_endpoint=AZURE_OPENAI_ENDPOINT
    )


def extract_keywords(text: str):
    response = azure_openai_client.chat.completions.create(
        model=AZURE_OPENAI_GPT_4O_MODEL_NAME,
        messages=[{"role": "system", "content": "Extract keywords from the following text."},
                  {"role": "user", "content": text}]
    )
    keywords = response.choices[0].message.content.split(", ")
    return keywords
