from fastapi import APIRouter, HTTPException
from core.handlers.text_processor import process_text, get_history
from app_constants.models import TextRequest, HistoryResponse

router = APIRouter()


@router.post("/process")
async def process_text_api(request: TextRequest):
    try:
        return process_text(request.text)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/history", response_model=HistoryResponse)
async def get_history_api():
    history = get_history()
    return history
